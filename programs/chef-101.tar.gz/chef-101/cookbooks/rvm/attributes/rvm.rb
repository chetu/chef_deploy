# rvm_ruby
set_unless[:rvm][:rvm_ruby] = "1.9.3"
# rvm_gemset
set_unless[:rvm][:rvm_gemset] = "gemset_name"


rvm_ruby = node[:rvm][:rvm_ruby]
rvm_gemset = node[:rvm][:rvm_gemset]
node[:apps].each do |app|


end


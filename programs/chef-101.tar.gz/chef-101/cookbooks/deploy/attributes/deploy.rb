set_unless[:deploy][:apps] = "/home/betteradmin/better_chef"
set_unless[:deploy][:deploy_mode] = "init"

